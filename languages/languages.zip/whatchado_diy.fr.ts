<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../aboutdialog.ui" line="14"/>
        <source>Über whatchado StoryRecorder</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;whatchado StoryRecorder - Version 1.76&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;http://www.whatchado.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.whatchado.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>HelpBP</name>
    <message>
        <location filename="../helpbp.ui" line="14"/>
        <source>Best Practice</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../helpbp.ui" line="43"/>
        <source>http://www.whatchado.com/de/diy/bestpractices</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>HelpHelp</name>
    <message>
        <location filename="../helphelp.ui" line="14"/>
        <source>FAQs</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../helphelp.ui" line="23"/>
        <source>https://www.whatchado.com/de/diy/help</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="../logindialog.ui" line="26"/>
        <source>Video Upload</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="54"/>
        <source>Neuen Benutzer anlegen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="109"/>
        <source>Vorname</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="122"/>
        <source>Nachname</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="135"/>
        <location filename="../logindialog.ui" line="220"/>
        <source>E-Mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="148"/>
        <location filename="../logindialog.ui" line="207"/>
        <source>Kennwort</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="161"/>
        <source>Sprache</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="175"/>
        <source>Deutsch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="180"/>
        <source>Englisch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="195"/>
        <source>Anmelden</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="262"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.cpp" line="93"/>
        <source>whatchado Fehler</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../logindialog.cpp" line="93"/>
        <source>Das Passwort muss mindesten 8 Zeichen haben</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>whatchado - Erzähl deine Story!</source>
        <translation type="vanished">whatchado - Racontez votre story!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>whatchado StoryRecorder</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>Home</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <location filename="../mainwindow.ui" line="838"/>
        <source>Anleitung</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="93"/>
        <location filename="../mainwindow.ui" line="833"/>
        <source>FAQs</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="117"/>
        <location filename="../mainwindow.cpp" line="1640"/>
        <location filename="../mainwindow.cpp" line="1648"/>
        <source>Preview...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="128"/>
        <source>Interview löschen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="203"/>
        <source>noch 3 Videos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="210"/>
        <source>UPLOAD</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="253"/>
        <source>https://www.whatchado.com/de/diy/start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="291"/>
        <source>PushButton</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <location filename="../mainwindow.cpp" line="1616"/>
        <source>Video auswählen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="305"/>
        <location filename="../mainwindow.cpp" line="1617"/>
        <source>Video löschen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="348"/>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="369"/>
        <location filename="../mainwindow.ui" line="395"/>
        <source>Auf der oberen der beiden Zeitleiste kannst du das Video abspielen. Auf der unteren Leiste kannst du den Bereich auswählen, den du für dein Interview verwenden möchtest. Klicke am Ende auf &quot;Video auswählen&quot;.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="382"/>
        <source>Anfang/Ende festlegen.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="416"/>
        <location filename="../mainwindow.ui" line="442"/>
        <location filename="../mainwindow.ui" line="459"/>
        <source>0:00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="478"/>
        <source>Zurück</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="498"/>
        <source>Video Editor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="524"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="615"/>
        <source>about:blank</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="704"/>
        <source>Video Aufnahme</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="809"/>
        <source>Hilfe</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="816"/>
        <source>Einstellungen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="828"/>
        <source>Test</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="843"/>
        <source>Settings</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="853"/>
        <source>Über</source>
        <translation></translation>
    </message>
    <message>
        <source>Einstellungen...</source>
        <translation type="vanished">Paramètres ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="848"/>
        <source>Beenden</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow_test.ui" line="14"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="360"/>
        <source>Kein Videogerät und Audiogerät oder Mikrofon gefunden.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="361"/>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Ohne Videogerät kannst du kein Video aufzeichnen, du darfst aber gern ein wenig in der App herumklicken.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="365"/>
        <source>Kein Videogerät gefunden.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="371"/>
        <source>Kein Audiogerät oder Mikrofon gefunden.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <source>Ohne Mikrofon kannst du kein Video aufzeichnen, du darfst aber gern ein wenig in der App herumklicken.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>Ja, ich will klicken!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="502"/>
        <source>Noch keine Videos erstellt.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="504"/>
        <source>Alle Videos erstellt, Du kannst das Interview jetzt hochladen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="506"/>
        <source> von </source>
        <comment>x von x videos erstellt</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="506"/>
        <source> Videos erstellt.</source>
        <comment>x von x videos erstellt</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="770"/>
        <source>https://www.whatchado.com/de/misc/faq</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="778"/>
        <source>https://www.whatchado.com/de/tutorial/diy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="842"/>
        <location filename="../mainwindow.cpp" line="1201"/>
        <source>Ja</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="843"/>
        <location filename="../mainwindow.cpp" line="1202"/>
        <source>Nein</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="844"/>
        <source>Wollen Sie Das Interview wirklich löschen?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="899"/>
        <source>Interviews</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1203"/>
        <source>Wollen Sie das Video wirklich löschen?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="906"/>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Neues Interview...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1641"/>
        <location filename="../mainwindow.cpp" line="1652"/>
        <source>Löschen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="995"/>
        <source> Aufnahme</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="997"/>
        <source> Aufnahmen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>Neue Antwort aufnehmen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1094"/>
        <source>Aufnehmen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="1605"/>
        <source>whatchado Fehler</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1584"/>
        <source>Upload erfolgreich!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1585"/>
        <source>Gib Deiner Story den letzten Schliff und teile sie mit der Welt!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1586"/>
        <source>Weiter zu meiner Story</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1593"/>
        <source>https://www.whatchado.com/de/users/stories</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1602"/>
        <source>Netzwerk Kommunkationsfehler</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1638"/>
        <source>Bearbeiten...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1760"/>
        <source>Speichere Video </source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../previewdialog.ui" line="20"/>
        <source>Video Preview</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../previewdialog.ui" line="45"/>
        <source>Play</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../previewdialog.ui" line="58"/>
        <source>Vorherige Frage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../previewdialog.ui" line="65"/>
        <source>Nächste Frage</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../interviews.cpp" line="167"/>
        <source>Student</source>
        <comment>videotype</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../interviews.cpp" line="168"/>
        <source>Job</source>
        <comment>videotype</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="13"/>
        <source>Was steht auf deiner Visitenkarte?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="14"/>
        <source>Worum geht’s in deinem Job?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="15"/>
        <source>Wie schaut dein Werdegang aus?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="16"/>
        <source>Ginge es auch ohne deinen Werdegang?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="17"/>
        <source>Was ist das Coolste an deinem Job?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="18"/>
        <source>Welche Einschränkungen bringt der Job mit sich?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="19"/>
        <source>3 Ratschläge an dein 14-jähriges Ich?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="23"/>
        <source>Wer bist du und was machst du?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="24"/>
        <source>Worum geht&apos;s in deinem Studium?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="25"/>
        <source>Wie bist du zu diesem Studium gekommen?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="26"/>
        <source>Welche Voraussetzungen sind nötig?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="27"/>
        <source>Was ist das Coolste an deinem Studium?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="28"/>
        <source>Was ist die öß Herausforderung?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="29"/>
        <source>3 Dinge, die du nach deinem Studium machen möchtest?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../questions.cpp" line="30"/>
        <source>Der wichtigste Ratschlag in deinem Leben?</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="63"/>
        <source>Video</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="91"/>
        <source>Audio</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="119"/>
        <source>Sprache</source>
        <translation></translation>
    </message>
    <message>
        <source>Zum Ändern der Einstellungen ist ein Neustart erforderlich.</source>
        <translation type="vanished">Pour modifier les paramètres un redémarrage est requis.</translation>
    </message>
</context>
<context>
    <name>StartView</name>
    <message>
        <location filename="../startview.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../startview.ui" line="32"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../startview.ui" line="45"/>
        <source>2</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UploadDialog</name>
    <message>
        <location filename="../uploaddialog.ui" line="14"/>
        <source>Interview Upload</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../uploaddialog.ui" line="42"/>
        <source>Interview</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../uploaddialog.ui" line="55"/>
        <source>Keine Sorge, das Interview geht erst online wenn Du das willst. Nach dem Upload.....</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../uploaddialog.ui" line="103"/>
        <source>Interview hochladen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../uploaddialog.ui" line="116"/>
        <source>Account erstellen....</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../uploaddialog.ui" line="139"/>
        <source>E-Mail</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UploadProgressDialog</name>
    <message>
        <location filename="../uploadprogressdialog.ui" line="14"/>
        <source>Video Upload...</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Welcome</name>
    <message>
        <location filename="../welcome.ui" line="14"/>
        <source>whatchado StoryRecorder</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../welcome.ui" line="30"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Allgemeine Geschäftsbedingungen für Whatchado – Do It Yourself Interview&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;1. Geltungsbereich&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;1.1 Die Allgemeinen Geschäftsbedingungen (nachfolgend „AGB&amp;quot;) gelten für alle Vertragsverhältnisse zwischen whatchado GmbH (nachfolgend „whatchado&amp;quot;) und allen Nutzern der Website, einschließlich solcher Nutzer, die Videoinhalte, Informationen und andere Materialien oder Dienste zu whatchado beitragen (nachfolgend „Nutzer“) und regeln die wechselseitigen Rechte und Pflichten zwischen den Vertragspartnern. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;1.2 Soweit für bestimmte Leistungen außerhalb dieser AGB abweichende spezielle Regelungen getroffen werden, gelten vorrangig die speziellen Regelungen vor diesen AGB.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;2. Annahme der Bestimmungen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;2.1 Die Nutzung der Dienste (Website und jegliche Produkte, Software und Dienste nachfolgend  „Dienste“) ist nur nach Zustimmung der AGB durch den Nutzer möglich. Das Nutzen der Dienste ist untersagt, sofern der Nutzer die AGB nicht annimmt.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;3. Änderungen der Bestimmungen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;3.1 Whatchado behält sich das Recht vor die AGB jederzeit ohne Angabe von Gründen und ohne vorherige Ankündigung ändern zu dürfen. Dem Nutzer wird empfohlen regelmäßig die AGB auf Aktualität zu überprüfen. Es gilt jeweils die aktuelle auf der Webseite veröffentliche Version der AGB. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;4. Gegenstand&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;4.1 Whatchado bietet Nutzern die Möglichkeit im Sinne der Förderung von Bewusstseinsbildung und Inspiration anderer Menschen durch die „Do-It-Yourself-Interview“-Funktion der Plattform unentgeltlich ein oder mehrere Videos mit Interviewpartnern aufzunehmen. Der Interviewpartner kann der Nutzer selbst oder ein Dritter sein. Die Videos werden über whatchado gestaltet bzw. veröffentlicht. In dem Interview werden dem Interviewpartner vorgegebene Fragen zu seinem beruflichen Werdegang gestellt. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;4.2 Die Videos werden entweder mittels einer eigenen Videosoftware (die „Videosoftware“), welche von whatchado im Rahmen der Nutzungsbedingungen in Punkt 9 zur Verfügung gestellt wird, erstellt oder der Interviewpartner produziert die Videoteile, welche seine Antworten aufzeichnen, selbst und lädt diese auf die Webseite, wo sie dann automatisiert zusammengeschnitten werden. Die Videointerviews zeigen abwechselnd die Interviewfragen mittels Einblendung und die Antwort des Interviewpartners.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;4.3 Die von den Nutzern hochgeladenen Videos sind auf der whatchado – Webseite (www.whatchado.com) öffentlich zugänglich und von jedem Besucher ansehbar. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5. Nutzerkonten&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.1 Die Nutzung eines Großteils der Funktionen auf der Webseite erfordert keine Registrierung. Um Zugang zu zusätzlichen Funktionen und Diensten – wie die „Do-It-Yourself-Interview“-Funktion – der Webseite zu erhalten, ermöglicht es whatchado dem Nutzer sich gratis auf whatchado.com zu registrieren und ein eigenes Nutzerkonto zu erstellen. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.2 Die Registrierung erfolgt durch Eingabe der E-Mail-Adresse des Nutzers und Registrierungsbestätigung durch whatchado auf unbestimmte Zeit. Anschließend kann der Nutzer ein Profil anlegen. Im Zuge der Erstellung des Nutzerkontos, ist es erforderlich, wahre und vollständige Angaben zu machen. Die Angabe von falscher, unvollständiger, irreführender oder sonst rechtswidriger Information ist unzulässig.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.3 Nach erfolgreicher Registrierung und Erstellung des Nutzerkontos ist es dem Nutzer möglich, ein Interview aufzunehmen und so ein Video zu erstellen und auf der Webseite von whatchado zu veröffentlichen. Um das Video einer Berufssparte zuordnen zu können, kann der Nutzer eine Bezeichnung aus einer von whatchado vorgegebenen Liste wählen oder selbst einen gewünschten Namen für die Berufsbezeichnung wählen. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.4 Mit Registrierung und Erstellung des Nutzerkontos stimmt der Nutzer ausdrücklich zu, dass sein Name und sein Videointerview auf der Webseite öffentlich sichtbar sind. Ebenso stimmt der Nutzer mit seiner Registrierung zu, dass andere registrierte Nutzer (auch Jobanbieter) Kontakt aufnehmen können.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.5 Der Nutzer ist zur Geheimhaltung des Kennworts seines whatchado Nutzerkontos verpflichtet und muss es sicher aufbewahren. Der Nutzer kann sein Kennwort jederzeit ändern. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.6 Der Nutzer erklärt sich damit einverstanden whatchado unverzüglich von jeder ihm bekannt werdenden Verletzung von Sicherheitsvorkehrungen oder einem unbefugten Gebrauch seines Nutzerkontos in Kenntnis zu setzen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.7 Der Nutzer erklärt sich damit einverstanden, dass er wegen jeglicher Aktivitäten, die unter seinem Nutzerkonto vorgenommen werden, alleine verantwortlich ist (sowohl gegenüber whatchado als auch gegenüber Dritten).&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5.8 Der Nutzer hat jederzeit die Möglichkeit sein Nutzerkonto zu deaktivieren und die Videointerviews von der Plattform zu nehmen. Der Nutzer kann whatchado auch direkt kontaktieren und die Entfernung einzelner Videos oder die Löschung des Nutzerkontos verlangen. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;6. Preise&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;6.1 Whatchado stellt seine Leistungen im Zuge der „Do-It-Yourself-Interview“-Funktion der Webseite den Nutzern nach Erstellung eines Nutzerkontos unentgeltlich zur Verfügung. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7. Generelle Nutzungsbeschränkungen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7.1 Handlungsweisen und das Einsetzen von (automatisierten) Systemen, welche die Sicherheit des Netzwerkes oder des Systems oder sonstige Zugriffe auf die Webseite beeinträchtigen oder dies beabsichtigen  sind verboten. Insbesondere ist das Einsetzen von Schadsoftware (z.B. Viren, Trojaner) und Programmen, welche automatisiert Daten und Informationen extrahieren (z.B. Robots, Spiders, Offline-Readers) verboten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7.2 Whatchado erneuert sich ständig, um seinen Nutzern ein bestmögliches Erlebnis zu vermitteln. Der Nutzer nimmt dies zur Kenntnis und erklärt sich damit einverstanden, dass sich die Form und Natur der Dienste, die whatchado zur Verfügung stellt, dementsprechend ändern kann, ohne dass dem Nutzer dies zuvor angekündigt wird.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7.3 Der Nutzer ist damit einverstanden, dass er allein verantwortlich ist (und dass whatchado dem Nutzer oder Dritten gegenüber nicht verantwortlich ist) im Zusammenhang mit und für die Folgen von jeder Verletzung dieser AGB durch den Nutzer (einschließlich jeglichen Verlusts oder Schadens, den whatchado dadurch erfährt).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7.4 Der Nutzer wird Zugangsdaten nur zum Zwecke der Nutzung im Rahmen des vertraglichen Umfangs weitergeben. Er verpflichtet sich, allen Personen und Organisationen, denen er Zugang zur Verwaltung der Plattform einräumt, die Bestimmungen über die Rechtseinräumungen (nachstehender Punkt 9) zur Kenntnis zu bringen und ausdrücklich darauf hinzuweisen, dass die Verantwortlichkeit für die Einhaltung rechtlicher Bestimmungen ausschließlich beim Nutzer liegt. Dies gilt insbesondere auch für gewerbliche Schutzrechte Dritter, urheberrechtliche Nutzungsrechte, Ansprüche von Verwertungsgesellschaften oder den Schutz von Persönlichkeitsrechten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8. Datenschutz und Verwertung&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.1 Der Nutzer erstellt selbst ein in Bild und Ton aufgezeichnetes Interview und stellt es auf der Webseite zur Verfügung. Ausdrücklich weist whatchado den Nutzer darauf hin, dass das Thema des Interviews seine Privatsphäre betrifft und ihm alleine die Entscheidung obliegt, inwieweit er diese der Öffentlichkeit präsentieren will.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.2 Der Nutzer räumt whatchado eine uneingeschränkte Werknutzungsbewilligung an sämtlichen vom Nutzer zur Verfügung gestellten Inhalten und Materialien, insbesondere der Videointerviews, ein, inklusive deren Speicherung, Verwertung, Vervielfältigung, Verbreitung, Sendung und öffentlicher Zurverfügungstellung. Die Auswahl behält sich whatchado vor. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.3 whatchado ist berechtigt, zur Erfüllung des Vertragszwecks die vom Nutzer zur Verfügung gestellten Inhalte und Materialien für weitere Verwendungen zu bearbeiten oder zu kürzen. Whatchado steht nicht dafür ein, dass Kürzungen nicht zu einer Veränderung des Sinngehaltes führen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.4 Die Veröffentlichung des Interviews dient vorrangig der Bewusstseinsbildung in der Gesellschaft, soll darüber hinaus aber auch die Leistungen von whatchado bewerben. Der Interviewpartner nimmt zur Kenntnis und stimmt zu, dass er - im Zusammenhang mit dem Projekt - mit seinem Namen und seinem Bild als Interviewpartner von whatchado benannt wird und er insofern whatchado als Institution unterstützt und bewirbt. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.5 Derzeit werden die Interviews auf der whatchado Website (www.whatchado.com) weltweit der Öffentlichkeit zum Abruf zur Verfügung gestellt. Zum Zwecke einer möglichst weitreichenden Bewusstseinsbildung ist der Nutzer damit einverstanden, dass whatchado die endgültige Version des Interviews/der Interviewreihe (ganz oder teilweise) auch in anderen Medien, beispielsweise im Rundfunk, Kino oder in Sozialen Medien (Facebook, Youtube etc.), allenfalls auch als Lichtbild in Verbindung mit einem Zitat in einem Printmedium, veröffentlicht, ankündigt, bewirbt oder verwertet. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8.6 Das Videointerview kann zum Zwecke der sinnvollen Verbreitung zu Berufsorientierungszwecken bei Bildungs- und Berufskooperationspartnern von whatchado eingebunden werden. whatchado garantiert, dass das Interview immer klar und deutlich als whatchado-Videointerview gekennzeichnet sein wird und niemals aus dem inhaltlichen Zusammenhang gerissen wird. Whatchado garantiert jedoch nicht, dass die Videointerviews immer nur auf whatchado.com laufen oder anderweitige Einbindungen immer nur auf das Videointerview auf whatchado.com zugreifen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9. Rechte&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9.1 Im Rahmen des Vertragsverhältnisses werden Rechte seitens whatchado nur in dem Umfang übertragen, wie dies für die Vertragsdurchführung unerlässlich ist. Der Nutzer erkennt an, dass er mit der vorübergehenden Nutzung von Marken oder Kennzeichen von whatchado keine eigenen Rechte erwirbt. Der Nutzer ist nicht berechtigt, Marken oder Kennzeichen, die whatchado im Rahmen der Vertragsdurchführung verwendet, zu verändern oder zu entfernen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9.2 whatchado gewährt dem Nutzer an der Videosoftware das nicht ausschließliche, zeitlich auf die Dauer des Vertragsverhältnisses beschränkte Recht, die Videosoftware zur Erstellung von Videointerviews zu nutzen. Der Nutzer hat darüberhinaus das Recht, die Videosoftware für diesen Zweck an Dritte weiterzugeben.&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9.3 Soweit der Nutzer im Rahmen der Vertragsdurchführung eigene Materialien (Videos, Grafiken, Logos, Texte, Musik etc.) verwendet oder einbringt, sichert er zu über sämtliche Nutzungs- und Verwertungsrechte zu verfügen.  Des Weiteren sichert der Nutzer zu, die Einwilligung und Zustimmung allfällig abgebildeter oder gefilmter dritter Personen für die Veröffentlichung der Materialien, insbesondere der Videointerviews, zu haben. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9.4 Der Nutzer hat whatchado umgehend schriftlich über einen allfälligen Verlust von Nutzungs- und Verwertungsrechten zu unterrichten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9.5 Der Nutzer hält whatchado schad- und klaglos und stellt whatchado von sämtlichen Ansprüchen inklusive der Kosten der angemessenen Rechtsverteidigung frei, die Dritte gegen whatchado wegen einer Verletzung von Rechten Dritter oder einem Verstoß gegen gesetzliche Vorschriften im Zusammenhang mit der Nutzung der Leistungen, insbesondere der Verbreitung von Inhalten, durch den Nutzer geltend machen. Der Nutzer wird whatchado bei allen gerichtlichen und außergerichtlichen Auseinandersetzungen unterstützen und alle Daten, Dokumente und sonstigen Materialien, die whatchado im Rahmen der Auseinandersetzung für notwendig erachtet, auf Verlangen unverzüglich zur Verfügung stellen. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10. Inhaltliche Verantwortung des Nutzers&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10.1. Verantwortlich für die gespeicherten und veröffentlichten oder verbreiteten Inhalte ist ausschließlich der Nutzer.&lt;br /&gt;&lt;br /&gt; whatchado ist lediglich technischer Dienstleister.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10.2 Der Nutzer verpflichtet sich, nur solche Inhalte zu verwalten, zu speichern, zu verbreiten oder zu veröffentlichen, die rechtmäßig sind. Er wird insbesondere keine gewaltverherrlichenden, rassistischen, pornografischen, anstößigen, sonst jugendgefährdenden oder beleidigenden Inhalte speichern oder über die zur Verfügung gestellten Dienste verbreiten.&lt;br /&gt;&lt;br /&gt;Weiters wird der Nutzer, weder im Video noch im Beschreibungstext Werbung, Werbelinks oder sonstige Aktionsaufrufe, insbesondere solche, welche den Kauf von Produkten oder Spenden fördern oder bewerben, platzieren, speichern oder verbreiten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10.3 Der Nutzer verpflichtet sich, nur Videos und keine Fotographien auf die Plattform hochzuladen und dafür Sorge zu tragen, dass per Video nur eine Person interviewt wird und deren Gesicht erkennbar und der Ton verständlich ist.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10.4 whatchado ist nicht verpflichtet eine eigene Prüfung der Inhalte durchzuführen; eine Hinweispflicht seitens whatchado auf etwaige problematische Inhalte besteht daher nicht. whatchado ist jedoch berechtigt, die Verbreitung oder Veröffentlichung problematischer Inhalte ohne Einhaltung von Fristen und ohne vorherige Ankündigung dauerhaft oder zeitweise zu verhindern, zu löschen oder ganz oder teilweise für alle oder einige Nutzer zu sperren, wenn sie gegen gesetzliche oder behördliche Regelungen oder die guten Sitten verstoßen oder aus sonstigen begründeten Fällen die Veröffentlichung nicht zugemutet werden kann. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10.5 Der Nutzer verpflichtet sich, die zur Verfügung gestellten technischen Ressourcen ausschließlich vertragskonform zu verwenden. Er wird insbesondere keine Dateien speichern, verbreiten, veröffentlichen oder sonst in die zur Verfügung gestellten Dienste und Leistungen einbringen, welche die technische Funktion des Systems beeinträchtigen oder gefährden könnten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11. Links&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11.1 Die Dienste können Hyperlinks auf andere Webseiten enthalten, die nicht whatchado gehören oder von whatchado kontrolliert werden. Whatchado hat keine Kontrolle und übernimmt keine Haftung für die Inhalte, Datenschutz-Richtlinien oder Tätigkeiten fremder Webseiten.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11.2 Der Nutzer nimmt zur Kenntnis und erklärt sich damit einverstanden, dass whatchado nicht für die Verfügbarkeit solcher externen Seiten oder Quellen verantwortlich ist und nicht irgendwelche Werbung, Produkte oder andere Materialien, die auf solchen Webseiten stehen oder über sie verfügbar sind, Verantwortung übernimmt oder bekräftigt.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11.3 Der Nutzer nimmt zur Kenntnis und erklärt sich damit einverstanden, dass whatchado nicht verantwortlich ist für irgendwelche Verluste oder Schäden, die der Nutzer als Folge der Verfügbarkeit solcher externen Webseiten oder Quellen oder als Folge seines Vertrauens in die Vollständigkeit, Richtigkeit oder die Existenz irgendwelcher Werbung, Produkte oder anderer Materialien, die auf solchen Webseiten stehen oder über sie verfügbar sind, treffen können.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11.4 Weiters kann der vom Nutzer zur Verfügung gestellte Content – Content steht in diesem Fall für Videos, Grafiken, Logos, Texte, Musik etc. – mittels Embed Code, iFrame, Download oder sonstigen Links auf externen Seiten, u.a. Websites, Social Media, Blogs etc., integriert werden, selbst wenn diese von Servern außerhalb Österreichs gehosted werden. Diese Integration kann vom Nutzer selbst, whatchado, den Partnern von whatchado und allen anderen Parteien, die die Website von whatchado nutzen, erfolgen. Der Nutzer erklärt sich damit einverstanden.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11.5 whatchado empfiehlt dem Nutzer, beim Verlassen der Webseite von whatchado wachsam zu sein und sich die Nutzungsbedingungen und Datenschutz-Richtlinien jeder anderen Webseite, die der Nutzer besucht, durchzulesen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;12. Dauer /Auflösung&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Verträge zwischen whatachdo und dem Nutzer werden in der Regel auf unbestimmte Zeit abgeschlossen und kann von beiden Parteien unter Einhaltung einer Kündigungsfrist von 2 Wochen zum Ende eines Kalendermonats beendet werden. Die sofortige Auflösung aus wichtigem Grund ist unabhängig davon jederzeit möglich. Festgehalten wird, dass whatchado im Sinne der Rechteinhaberschaft (siehe Punkt 8) auch nach Vertragsauflösung (aus welchem Grund immer) – vor allem im Sinne der Bewerbung von whatchado – weiter berechtigt bleibt, die zur Verfügung gestellten Inhalte (mit und ohne Nennung des Vertragspartners) zu nutzen.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;13. Haftung&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Die Haftung von whatchado, ihren Organen und Erfüllungsgehilfen ist auf Vorsatz und grobe Fahrlässigkeit beschränkt. Die Haftung für Schäden durch leichte Fahrlässigkeit wird - mit Ausnahme von Schäden an Personen - ausgeschlossen.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;whatchado haftet nicht für die Vollständigkeit, Aktualität, Korrektheit oder sonstige Qualität der dargestellten Inhalte und Informationen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;14 Anwendbares Recht / Gerichtsstand&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;14.1 Dieser Vertrag unterliegt dem Recht der Republik Österreich, unter Ausschluss seiner Kollissionsnormen und des UN-Kaufrechts.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;14.2 Für allfällige Streitigkeiten aus oder im Zusammenhang mit diesem Vertrag wird die ausschließliche Zuständigkeit des für den 4. Wiener Gemeindebezirk sachlich zuständigen Gerichtes vereinbart.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../welcome.ui" line="181"/>
        <source>Akzeptieren</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>addinterview</name>
    <message>
        <location filename="../addinterview.ui" line="17"/>
        <source>Form</source>
        <comment>Interview</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="47"/>
        <source>Abbrechen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="70"/>
        <source>Interview Typ</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="86"/>
        <source>Ok</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="99"/>
        <source>Sprache</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="135"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.ui" line="151"/>
        <source>Interview Typ
Job: Beantworte 7 Fragen zu deinem Beruf und Werdegang.
Student: Beantworte 8 Fragen zu deinem Studium und Werdegang.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.cpp" line="71"/>
        <source>Fehler</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../addinterview.cpp" line="71"/>
        <source>Kein Name angegeben</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bitte gib deinem Interview einen Arbeitstitel.</source>
        <translation type="vanished">Donnez à votre interview un titre de travail.</translation>
    </message>
</context>
</TS>
